package ASM1;

import java.io.IOException;
import java.util.Scanner;

public class Main_Sort {
	public static int luaChon;
	

	public static void main(String[] args) throws IOException {
		Algorithm choice = new Algorithm();
//		Scanner sc = new Scanner(System.in);
//		int n = sc.nextInt();
//		float [] arrNum = new float[n];
//		for(int i=0; i<n; i++) {
//			int num = sc.nextInt();
//			arrNum[i]=num;
//		}
		while(true) {
			Menu();
			if(luaChon == 1) {
				Scanner sc = new Scanner(System.in);
				System.out.println("Input number of elements:  ");
				int n = sc.nextInt();
				float [] arrNum = new float[n];
				System.out.println("Input elements: ");
				for(int i=0; i<n; i++) {
					int num = sc.nextInt();
					arrNum[i]=num;
				}
				choice.writeFile("/Users/louis/Downloads/INPUT.TXT", arrNum);
			}
			if(luaChon == 2) choice.readFile("/Users/louis/Downloads/INPUT.TXT");
			if(luaChon == 3) {
				float [] b = choice.readFile("/Users/louis/Downloads/INPUT.TXT");
				choice.bubbleSort(b);
			}
			if(luaChon == 4) {
				float [] b = choice.readFile("/Users/louis/Downloads/INPUT.TXT");
				choice.selectionSort(b);
			}
			if(luaChon == 5) {
				float [] b = choice.readFile("/Users/louis/Downloads/INPUT.TXT");
				choice.insertionSort(b);
			}
			if(luaChon == 6) {
				float [] b = choice.readFile("/Users/louis/Downloads/INPUT.TXT");
				Scanner sc = new Scanner(System.in);
				int value = sc.nextInt();
				choice.search(b, value);
			}
		    if(luaChon == 7) {
		    	Scanner sc = new Scanner(System.in);
		    	int val = sc.nextInt();
		    	float [] b = choice.readFile("/Users/louis/Downloads/OUTPUT3.TXT");
		    	int a= b.length;
		    	int t = choice.binarySearch(b, a, val);
		    	String s = String.valueOf(t);
		    	if(t== -1) {
		    		String text = "not found";
		    		choice.writeFileStr("/Users/louis/Downloads/OUTPUT5.TXT", text);		    		
		    	}else choice.writeFileStr("/Users/louis/Downloads/OUTPUT5.TXT", s);
		    	
		    }
			if(luaChon == 0) {
				System.out.println("Thanks!!!");
				break;
			}
			}

	}
	public static void Menu() {
		Scanner sc = new Scanner(System.in);
		System.out.println("+-------------------Menu------------------+");
		System.out.println("|      1.Input                            |");
		System.out.println("|      2.Out                              |");
		System.out.println("|      3.Bubble sort                      |");
		System.out.println("|      4.Selection sort                   |");
		System.out.println("|      5 Insertion sort t                 |");
		System.out.println("|      6.Search > value                   |");
		System.out.println("|      7.Search = value                   |");
		System.out.println("|      0.Exit                             |");
		System.out.println("+----------------------------------------.+");
		luaChon = sc.nextInt();
		sc.nextLine();
		
	}
}
