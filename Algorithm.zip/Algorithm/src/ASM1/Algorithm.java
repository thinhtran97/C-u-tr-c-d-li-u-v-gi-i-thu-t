package ASM1;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Algorithm {
	/**

	  * Writing the array read from input array arr to file

	  *

	  * @param fileName The file name of file to write value

	  * @param arr      The input float array
	 * @throws IOException 

	  *

	  */
	public void writeFile(String fileName, float[] arr) throws IOException  {
		try {
            FileWriter fw = new FileWriter(fileName);
            for(int i=0;i<arr.length;i++){
            	fw.write(arr[i]+" ");
            }
            fw.close();
        } catch (Exception e) {
            System.out.println(e);
          }
        System.out.println("Success...");
	 }
	
	public static void writeFileStr(String fileName, String text) throws IOException {
		try {
		FileWriter fw = new FileWriter(fileName);
		fw.write(text);
		fw.close();
		} catch (Exception e) {
		System.out.println(e);
		}
		System.out.println("Success...");
		}

	 

	 /**

	  * Reading the file then input to the array arr

	  *

	  * @param fileName The file name of file to read

	  * @return Returning a array read from the file
	 * @throws IOException 

	  */

	 public float[] readFile(String fileName) throws IOException {
		 
		 FileInputStream inputStream = new FileInputStream(fileName);
		 byte buff[] = new byte[1024];
		 int length = inputStream.read(buff);
		 String text = "";
		 // Chạy vòng while đọc đến khi gặp ký hiệu kết thúc file (-1)
		 while (length > 0) {
		 //Chuyển mảng buff sang định dạng chuỗi
		 text += new String(buff, 0, length);
		// System.out.println(text);
		 length = inputStream.read(buff);
		 }
		 
		 String []word = text.split(" ");
		 float []a= new float[word.length];
		 for(int i=0;i<a.length;i++)
			 a[i]=Float.parseFloat(word[i]);
		 for (int i = 0; i < a.length ; ++i) {
             System.out.print(a[i] + " ");
             }
      System.out.println();

		return a;

	 }

	 

	 /**

	  * Sorting the input array arr using Bubble Sort algorithm.

	  *

	  * @param arr Input array using for sorting

	  * @return Returning a sorted array by using the Bubble Sort algorithm
	 * @throws IOException 

	  *

	  */
	 public float[] bubbleSort(float arr[]) throws IOException {
		 int n = arr.length;
	        for (int i = 0; i < n -1 ; i++) {
	            for (int j = 0; j < n - i - 1 ; j++) {
	                if (arr[j] > arr[j + 1]) {
	                    // swap arr[j+1] và arr[i]
	                    float temp = arr[j];
	                    arr[j] = arr[j + 1];
	                    arr[j + 1] = temp;
	                    
	        }
	         for (int a = 0; a < n; ++a) {
	                System.out.print(arr[a] + " ");}
	         System.out.println();
	         }
	         }
	        writeFile("/Users/louis/Downloads/OUTPUT1.TXT",arr);
			return arr;
	 }
	

	 

	 /**

	  * Sorting the input array arr using Selection Sort algorithm.

	  *

	  * @param arr Input array using for sorting

	  * @return Returning a sorted array by using the Selection Sort algorithm
	 * @throws IOException 

	  *

	  */

	 public float[] selectionSort(float arr[]) throws IOException {
		 int n = arr.length;

	        // Duyệt qua từng phần tử của mảng
	        for (int i = 0; i < n - 1; i++) {

	            // Tìm phần tử nhỏ nhất trong mảng chưa được sắp xếp
	            int min_idx = i;
	            for (int j = i + 1; j < n; j++) {
	                if (arr[j] < arr[min_idx])
	                    min_idx = j;

	            // Hoán đổi phần tử nhỏ nhất và phần tử đầu tiên
	            float temp = arr[min_idx];
	            arr[min_idx] = arr[i];
	            arr[i] = temp;
	            
	            for (int a = 0; a < n; ++a) {
	                System.out.print(arr[a] + " ");}
	            System.out.println();
	            }
	            }
	        writeFile("/Users/louis/Downloads/OUTPUT2.TXT",arr);
		return arr;

	 }

	 

	 /**

	  * Sorting the input array arr using Insertion Sort algorithm.

	  *

	  * @param arr Input array using for searching

	  * @return Returning a sorted array by using the Insertion Sort algorithm
	 * @throws IOException 

	  *

	  */

	 public float[] insertionSort(float arr[]) throws IOException {
		 int n = arr.length;
	        for (int i = 1; i < n; ++i) {
	            float key = arr[i];
	            int j = i - 1;

	            // Di chuyển các phần tử của arr [0 ... i - 1], lớn hơn key
	            // đến một vị trí trước vị trí hiện tại của chúng
	            while (j >= 0 && arr[j] > key) {
	                arr[j + 1] = arr[j];
	                j = j - 1;
	            }
	            arr[j + 1] = key;
	            for (int a = 0; a < n; ++a) {
	                System.out.print(arr[a] + " ");}

	            System.out.println();
	        }
	        writeFile("/Users/louis/Downloads/OUTPUT3.TXT",arr);
		return arr;

	 }

	 

	 /**

	  * Searching the indices of elements in array [arr] greater than value. Printing

	  * and writing all indices to the console screen and file OUTPUT4.TXT separated by space.

	  *

	  * @param arr   Input array using for searching

	  * @param value The value for searching
	 * @throws IOException 

	  *

	  */

	 public void search(float arr[], float value) throws IOException {
		 int N = arr.length;
	        String text = "";
	        boolean found = false;
	        
	        for (int i = 0; i < N; i++) {
	            if (arr[i] > value) {
	               text += i + " "; 
	               found = true;
	            }	
				}
	        if(found == false) text= "not found";
	        writeFileStr("/Users/louis/Downloads/OUTPUT4.TXT",text);
	 }

	 

	 /**

	  * Searching by using the Binary Search algorithm. Returning the first index of

	  * value if it is present in array arr, otherwise, return -1. The index also

	  * written to file OUTPUT5.TXT and shown on the console screen.

	  *

	  * @param arr   Input array using for searching

	  * @param left  The left index

	  * @param right The right index

	  * @param value The value for searching

	  * @return The index of the element if found, otherwise, return -1
	 * @throws IOException 

	  *

	  */

	 public int binarySearch(float arr[], int n, float value) throws IOException {
		 int l = 0, r = n-1;
		  while(l<r) {
			  int mid = (l+r)/2;
			  if(arr[mid]<value) {
				  l=mid+1;
			  }
			  else {r=mid;}
		  }
		  if(arr[l]==value) {
			  return l;
			  }
		return -1;
		 
		    

	 }
}
